#!/bin/sh

aclocal

autoconf
