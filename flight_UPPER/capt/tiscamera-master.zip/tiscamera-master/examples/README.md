# The Imaging Source Linux Repository

## Examples

This section contains some sample codes for handling cameras, that have been done during support sessions.

### showcamera
This sample shows how to use the USB camera with GStreamer in an GUI program.

## Licensing

All files are published under the Apache License 2.0.

